UPDATE ezcontentclass_attribute SET data_text5=data_text4 where data_type_string= 'ngremotemedia';

