#!/bin/sh
sass \
--style compressed \
--watch \
ezpublish_legacy/ngremotemedia/design/standard/stylesheets/ngremotemedia.scss:ezpublish_legacy/ngremotemedia/design/standard/stylesheets/ngremotemedia.css
